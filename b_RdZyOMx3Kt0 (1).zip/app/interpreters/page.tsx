import { InterpretersListing } from "@/components/interpreters-listing";

export default function InterpretersPage() {
  return <InterpretersListing />;
}
