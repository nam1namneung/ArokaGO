"use client";

import { useState } from "react";
import { OnboardingRoleSelect } from "@/components/onboarding-role-select";
import { UserProfileForm } from "@/components/user-profile-form";
import { ProviderProfileForm } from "@/components/provider-profile-form";
import { CheckCircle2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

type Step = "role" | "form" | "success";

export default function OnboardingPage() {
  const [step, setStep] = useState<Step>("role");
  const [role, setRole] = useState<"user" | "provider" | null>(null);

  const handleRoleSelect = (selectedRole: "user" | "provider") => {
    setRole(selectedRole);
    setStep("form");
  };

  const handleComplete = () => {
    setStep("success");
  };

  if (step === "role") {
    return <OnboardingRoleSelect onSelect={handleRoleSelect} />;
  }

  if (step === "form") {
    if (role === "user") {
      return <UserProfileForm onComplete={handleComplete} />;
    }
    return <ProviderProfileForm onComplete={handleComplete} />;
  }

  return (
    <div className="min-h-[100dvh] bg-background flex items-center justify-center px-4 py-8">
      <div className="bg-card rounded-2xl shadow-xl border border-border p-6 md:p-10 max-w-md w-full text-center">
        <div className="h-14 w-14 md:h-16 md:w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
          <CheckCircle2 className="h-7 w-7 md:h-8 md:w-8 text-primary" />
        </div>
        <h2 className="text-xl md:text-2xl font-bold text-foreground mb-2">
          Profile Saved!
        </h2>
        <p className="text-sm text-muted-foreground leading-relaxed mb-6">
          {role === "user"
            ? "Your patient profile has been set up. You can now explore providers and book consultations."
            : "Your provider profile has been submitted for review. You will be notified once it goes live."}
        </p>
        <div className="flex flex-col gap-2.5">
          <Link href={role === "user" ? "/chat" : "/"}>
            <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-11 text-sm font-semibold gap-2">
              {role === "user" ? "Start Consultation" : "Go to Dashboard"}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <Link href="/">
            <Button
              variant="outline"
              className="w-full rounded-xl h-11 text-sm font-semibold border-border hover:bg-muted bg-transparent"
            >
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
