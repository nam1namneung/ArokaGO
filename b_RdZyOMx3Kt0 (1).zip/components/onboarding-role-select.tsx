"use client";

import { User, Building2, ArrowRight, ShieldCheck } from "lucide-react";

interface RoleSelectProps {
  onSelect: (role: "user" | "provider") => void;
}

export function OnboardingRoleSelect({ onSelect }: RoleSelectProps) {
  return (
    <div className="min-h-[100dvh] bg-background flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-8 md:mb-10">
          <div className="flex items-center justify-center gap-1 mb-4">
            <span className="text-xl md:text-2xl font-bold text-foreground tracking-tight">
              Aroka
            </span>
            <span className="text-xl md:text-2xl font-bold text-primary">GO</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-foreground text-balance mb-2">
            Complete Your Profile
          </h1>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Select your role to get started with a personalized onboarding guide.
          </p>
        </div>

        <div className="flex flex-col gap-3 md:gap-4">
          <button
            onClick={() => onSelect("user")}
            className="group bg-card border border-border rounded-2xl p-5 md:p-6 text-left hover:border-primary/50 hover:shadow-lg transition-all"
          >
            <div className="flex items-start gap-4">
              <div className="h-11 w-11 md:h-12 md:w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                <User className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-[15px] md:text-base font-semibold text-foreground">
                    Patient / User
                  </h3>
                  <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <p className="text-xs md:text-sm text-muted-foreground mt-1 leading-relaxed">
                  I am looking for medical care in Thailand. Set up your health
                  profile, travel preferences, and insurance details.
                </p>
              </div>
            </div>
          </button>

          <button
            onClick={() => onSelect("provider")}
            className="group bg-card border border-border rounded-2xl p-5 md:p-6 text-left hover:border-primary/50 hover:shadow-lg transition-all"
          >
            <div className="flex items-start gap-4">
              <div className="h-11 w-11 md:h-12 md:w-12 rounded-xl bg-accent flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                <Building2 className="h-5 w-5 md:h-6 md:w-6 text-accent-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-[15px] md:text-base font-semibold text-foreground">
                    Medical Provider
                  </h3>
                  <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <p className="text-xs md:text-sm text-muted-foreground mt-1 leading-relaxed">
                  I am a hospital, clinic, or medical professional. Set up your
                  practice details, credentials, and services.
                </p>
              </div>
            </div>
          </button>
        </div>

        <div className="flex items-center justify-center gap-2 mt-6 md:mt-8 text-[11px] md:text-xs text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5 text-primary" />
          <span>Your data is secure and encrypted</span>
        </div>
      </div>
    </div>
  );
}
