"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Send,
  Paperclip,
  Sparkles,
  Video,
} from "lucide-react";
import { Button } from "@/components/ui/button";

type Message = {
  id: string;
  role: "user" | "bot";
  content: string;
  timestamp: string;
  showBookingButton?: boolean;
};

const BOT_RESPONSES: Record<string, { content: string; showBooking?: boolean }> = {
  greeting: {
    content:
      "Hello! Welcome to ArokaGO. We help you plan your entire medical journey in one place. We connect you with trusted hospitals and clinics in Thailand, arrange appointments, estimate treatment costs, and support your travel and recovery needs.\n\nHow can I help you today?",
  },
  procedure: {
    content:
      "Knee replacement surgery is a procedure that replaces damaged knee joints to reduce pain and improve mobility.\n\nWould you like to:\n- Learn about recovery time\n- Get an estimated price",
  },
  price: {
    content:
      "Based on your selected treatment, the estimated cost for knee replacement surgery in Thailand ranges between THB 300,000 - 450,000, depending on the treatment plan.\n\nWould you like to book an appointment for consultation?",
    showBooking: true,
  },
  general: {
    content:
      "Thank you for your message. Our team of medical advisors can help you find the best treatment option in Thailand. Could you tell me more about:\n- What treatment or procedure you're interested in?\n- Your preferred budget range?\n- Any specific hospital or location preference?",
  },
};

function getTimeStamp() {
  return new Date().toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function detectIntent(message: string): string {
  const lower = message.toLowerCase();
  if (
    lower.includes("hello") ||
    lower.includes("hi") ||
    lower.includes("hey") ||
    lower.includes("start")
  ) {
    return "greeting";
  }
  if (
    lower.includes("knee") ||
    lower.includes("surgery") ||
    lower.includes("replacement") ||
    lower.includes("procedure") ||
    lower.includes("treatment")
  ) {
    return "procedure";
  }
  if (
    lower.includes("price") ||
    lower.includes("cost") ||
    lower.includes("how much") ||
    lower.includes("estimate") ||
    lower.includes("budget") ||
    lower.includes("expensive")
  ) {
    return "price";
  }
  return "general";
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "bot",
      content:
        "Hello! Welcome to ArokaGO. We help you plan your entire medical journey in one place. We connect you with trusted hospitals and clinics in Thailand, arrange appointments, estimate treatment costs, and support your travel and recovery needs.\n\nHow can I help you today?",
      timestamp: getTimeStamp(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  function handleSend() {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: getTimeStamp(),
    };

    setMessages((prev) => [...prev, userMessage]);
    const intent = detectIntent(input.trim());
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      const response = BOT_RESPONSES[intent] || BOT_RESPONSES.general;
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "bot",
        content: response.content,
        timestamp: getTimeStamp(),
        showBookingButton: response.showBooking,
      };
      setMessages((prev) => [...prev, botMessage]);
      setIsTyping(false);
    }, 1200);
  }

  return (
    <div className="flex flex-col h-[100dvh] bg-background">
      {/* Chat header */}
      <header className="flex items-center gap-3 px-3 py-2.5 md:px-4 md:py-3 bg-primary text-primary-foreground shadow-md safe-area-top">
        <Link href="/" className="flex items-center p-1">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div className="flex items-center gap-2.5 md:gap-3">
          <div className="h-9 w-9 md:h-10 md:w-10 rounded-full bg-primary-foreground/20 flex items-center justify-center shrink-0">
            <Sparkles className="h-4 w-4 md:h-5 md:w-5" />
          </div>
          <div>
            <h2 className="text-[13px] md:text-sm font-semibold">ArokaGO Medical Advisor</h2>
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 md:h-2 md:w-2 rounded-full bg-emerald-400" />
              <span className="text-[11px] md:text-xs opacity-80">Online</span>
            </div>
          </div>
        </div>
      </header>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto px-3 py-4 md:px-4 md:py-6">
        <div className="max-w-2xl mx-auto flex flex-col gap-3 md:gap-4">
          {messages.map((msg) => (
            <div key={msg.id}>
              <div
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[88%] sm:max-w-[75%] rounded-2xl px-3 py-2.5 md:px-4 md:py-3 text-[13px] md:text-sm leading-relaxed whitespace-pre-line ${
                    msg.role === "user"
                      ? "bg-foreground text-white rounded-br-md"
                      : "bg-muted text-foreground rounded-bl-md"
                  }`}
                >
                  {msg.content}
                </div>
              </div>

              {msg.showBookingButton && (
                <div className="flex justify-start mt-2.5 md:mt-3">
                  <Link href="/booking" className="w-full md:w-auto">
                    <Button className="w-full md:w-auto bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl gap-2 px-4 md:px-6 h-10 md:h-11 text-[13px] md:text-sm shadow-lg">
                      <Video className="h-4 w-4 shrink-0" />
                      Book online consultation slots
                    </Button>
                  </Link>
                </div>
              )}

              <p
                className={`text-[10px] text-muted-foreground mt-1 md:mt-1.5 ${msg.role === "user" ? "text-right" : "text-left"}`}
              >
                {msg.timestamp}
              </p>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3">
                <div className="flex gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce" />
                  <span
                    className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce"
                    style={{ animationDelay: "0.15s" }}
                  />
                  <span
                    className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce"
                    style={{ animationDelay: "0.3s" }}
                  />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input area */}
      <div className="border-t border-border bg-card px-3 py-2.5 md:px-4 md:py-3 safe-area-bottom">
        <div className="max-w-2xl mx-auto flex items-center gap-1.5 md:gap-2">
          <button
            className="text-muted-foreground hover:text-foreground transition-colors p-1.5 md:p-2 shrink-0"
            aria-label="Attach file"
          >
            <Paperclip className="h-5 w-5" />
          </button>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Type your message..."
            className="flex-1 min-w-0 bg-muted/50 border border-border rounded-full px-3 py-2 md:px-4 md:py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className="bg-primary text-primary-foreground rounded-full p-2 md:p-2.5 hover:bg-primary/90 transition-colors disabled:opacity-40 shrink-0"
            aria-label="Send message"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Footer bar */}
      <div className="bg-foreground text-center py-1.5 md:py-2">
        <span className="text-[11px] md:text-xs text-white/60">arokago.com</span>
      </div>
    </div>
  );
}
