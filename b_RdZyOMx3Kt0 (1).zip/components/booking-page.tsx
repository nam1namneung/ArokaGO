"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  CalendarDays,
  Clock,
  Video,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const TIME_SLOTS = [
  "09:00 AM",
  "09:30 AM",
  "10:00 AM",
  "10:30 AM",
  "11:00 AM",
  "11:30 AM",
  "01:00 PM",
  "01:30 PM",
  "02:00 PM",
  "02:30 PM",
  "03:00 PM",
  "03:30 PM",
  "04:00 PM",
  "04:30 PM",
];

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfMonth(year: number, month: number) {
  return new Date(year, month, 1).getDay();
}

const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function BookingPage() {
  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [selectedDate, setSelectedDate] = useState<number | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [isConfirmed, setIsConfirmed] = useState(false);

  const daysInMonth = getDaysInMonth(currentYear, currentMonth);
  const firstDay = getFirstDayOfMonth(currentYear, currentMonth);

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
    setSelectedDate(null);
    setSelectedTime(null);
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
    setSelectedDate(null);
    setSelectedTime(null);
  };

  function isDateDisabled(day: number) {
    const date = new Date(currentYear, currentMonth, day);
    const todayDate = new Date();
    todayDate.setHours(0, 0, 0, 0);
    return date < todayDate || date.getDay() === 0;
  }

  function handleConfirm() {
    if (selectedDate && selectedTime) {
      setIsConfirmed(true);
    }
  }

  if (isConfirmed) {
    return (
      <div className="min-h-[100dvh] bg-background flex items-center justify-center px-4 py-8">
        <div className="bg-card rounded-2xl shadow-xl p-6 md:p-12 max-w-md w-full text-center">
          <div className="h-14 w-14 md:h-16 md:w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5 md:mb-6">
            <CheckCircle2 className="h-7 w-7 md:h-8 md:w-8 text-primary" />
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-foreground mb-2 md:mb-3">
            Booking Confirmed!
          </h2>
          <p className="text-muted-foreground text-[13px] md:text-sm leading-relaxed mb-5 md:mb-6">
            Your video consultation has been scheduled for{" "}
            <span className="font-semibold text-foreground">
              {MONTH_NAMES[currentMonth]} {selectedDate}, {currentYear}
            </span>{" "}
            at{" "}
            <span className="font-semibold text-foreground">{selectedTime}</span>.
          </p>
          <div className="bg-accent/50 rounded-xl p-4 mb-6">
            <div className="flex items-center justify-center gap-2 text-sm text-accent-foreground">
              <Video className="h-4 w-4" />
              <span>A video link will be sent to your email before the session.</span>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <Link href="/chat">
              <Button
                variant="outline"
                className="w-full rounded-xl h-11 bg-transparent"
              >
                Back to Chat
              </Button>
            </Link>
            <Link href="/">
              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-11">
                Go to Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground px-3 py-3 md:px-4 md:py-4">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <Link href="/chat" className="flex items-center p-1">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-base md:text-lg font-semibold">Book Online Consultation</h1>
            <p className="text-[11px] md:text-xs opacity-80">
              Select a date and time for your video call
            </p>
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-3 py-5 md:px-4 md:py-8">
        {/* Consultation info card */}
        <div className="bg-card rounded-2xl shadow-lg border border-border p-4 md:p-5 mb-5 md:mb-6">
          <div className="flex items-start gap-3 md:gap-4">
            <div className="h-10 w-10 md:h-12 md:w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Video className="h-5 w-5 md:h-6 md:w-6 text-primary" />
            </div>
            <div>
              <h3 className="text-[13px] md:text-sm font-semibold text-foreground">
                Video Consultation
              </h3>
              <p className="text-[11px] md:text-xs text-muted-foreground mt-1 leading-relaxed">
                30-minute video call with a medical advisor to discuss your
                treatment plan, expected costs, and next steps.
              </p>
              <div className="flex items-center gap-3 md:gap-4 mt-2.5 md:mt-3">
                <span className="flex items-center gap-1 text-[11px] md:text-xs text-muted-foreground">
                  <Clock className="h-3 w-3 md:h-3.5 md:w-3.5" />
                  30 minutes
                </span>
                <span className="flex items-center gap-1 text-[11px] md:text-xs text-primary font-medium">
                  <CalendarDays className="h-3 w-3 md:h-3.5 md:w-3.5" />
                  Free consultation
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:grid md:grid-cols-2 gap-4 md:gap-6">
          {/* Calendar */}
          <div className="bg-card rounded-2xl shadow-lg border border-border p-4 md:p-5">
            <div className="flex items-center justify-between mb-4 md:mb-5">
              <h3 className="text-[13px] md:text-sm font-semibold text-foreground flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-primary" />
                Select Date
              </h3>
              <div className="flex items-center gap-1.5 md:gap-2">
                <button
                  onClick={prevMonth}
                  className="h-7 w-7 md:h-8 md:w-8 rounded-lg border border-border flex items-center justify-center hover:bg-muted transition-colors"
                  aria-label="Previous month"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <span className="text-xs md:text-sm font-medium min-w-[100px] md:min-w-[120px] text-center">
                  {MONTH_NAMES[currentMonth]} {currentYear}
                </span>
                <button
                  onClick={nextMonth}
                  className="h-7 w-7 md:h-8 md:w-8 rounded-lg border border-border flex items-center justify-center hover:bg-muted transition-colors"
                  aria-label="Next month"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Day headers */}
            <div className="grid grid-cols-7 gap-0.5 md:gap-1 mb-1.5 md:mb-2">
              {DAY_NAMES.map((day) => (
                <div
                  key={day}
                  className="text-[10px] font-medium text-muted-foreground text-center py-1"
                >
                  {day}
                </div>
              ))}
            </div>

            {/* Days grid */}
            <div className="grid grid-cols-7 gap-0.5 md:gap-1">
              {Array.from({ length: firstDay }).map((_, i) => (
                <div key={`empty-${i}`} />
              ))}
              {Array.from({ length: daysInMonth }).map((_, i) => {
                const day = i + 1;
                const disabled = isDateDisabled(day);
                const selected = selectedDate === day;
                const isToday =
                  day === today.getDate() &&
                  currentMonth === today.getMonth() &&
                  currentYear === today.getFullYear();

                return (
                  <button
                    key={day}
                    disabled={disabled}
                    onClick={() => {
                      setSelectedDate(day);
                      setSelectedTime(null);
                    }}
                    className={`h-8 md:h-9 w-full rounded-lg text-[11px] md:text-xs font-medium transition-all ${
                      disabled
                        ? "text-muted-foreground/30 cursor-not-allowed"
                        : selected
                          ? "bg-primary text-primary-foreground shadow-md"
                          : isToday
                            ? "bg-primary/10 text-primary hover:bg-primary/20"
                            : "text-foreground hover:bg-muted"
                    }`}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time slots */}
          <div className="bg-card rounded-2xl shadow-lg border border-border p-4 md:p-5">
            <h3 className="text-[13px] md:text-sm font-semibold text-foreground flex items-center gap-2 mb-4 md:mb-5">
              <Clock className="h-4 w-4 text-primary" />
              Select Time
            </h3>

            {!selectedDate ? (
              <div className="flex flex-col items-center justify-center py-8 md:py-12 text-center">
                <CalendarDays className="h-8 w-8 md:h-10 md:w-10 text-muted-foreground/30 mb-3" />
                <p className="text-xs md:text-sm text-muted-foreground">
                  Please select a date first
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-3 md:grid-cols-2 gap-1.5 md:gap-2">
                {TIME_SLOTS.map((time) => {
                  const selected = selectedTime === time;
                  return (
                    <button
                      key={time}
                      onClick={() => setSelectedTime(time)}
                      className={`rounded-xl py-2 md:py-2.5 px-2 md:px-3 text-[11px] md:text-xs font-medium border transition-all ${
                        selected
                          ? "bg-primary text-primary-foreground border-primary shadow-md"
                          : "border-border text-foreground hover:border-primary/50 hover:bg-primary/5"
                      }`}
                    >
                      {time}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Confirm button */}
        <div className="mt-5 md:mt-6 pb-4 md:pb-0">
          <Button
            onClick={handleConfirm}
            disabled={!selectedDate || !selectedTime}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-11 md:h-12 text-[13px] md:text-sm font-semibold gap-2 shadow-lg disabled:opacity-40"
          >
            <Video className="h-4 w-4" />
            Confirm Video Consultation
          </Button>
          {selectedDate && selectedTime && (
            <p className="text-center text-[11px] md:text-xs text-muted-foreground mt-2.5 md:mt-3">
              {MONTH_NAMES[currentMonth]} {selectedDate}, {currentYear} at{" "}
              {selectedTime}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
