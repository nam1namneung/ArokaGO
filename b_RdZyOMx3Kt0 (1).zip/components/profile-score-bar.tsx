"use client";

import { CheckCircle2, AlertCircle, TrendingUp } from "lucide-react";

interface ScoreSection {
  label: string;
  filled: number;
  total: number;
}

interface ProfileScoreBarProps {
  score: number;
  sections: ScoreSection[];
  role: "user" | "provider";
}

function getScoreColor(score: number) {
  if (score >= 80) return "text-emerald-600";
  if (score >= 50) return "text-amber-500";
  return "text-destructive";
}

function getBarColor(score: number) {
  if (score >= 80) return "bg-emerald-500";
  if (score >= 50) return "bg-amber-500";
  return "bg-destructive";
}

function getScoreLabel(score: number) {
  if (score >= 90) return "Excellent";
  if (score >= 75) return "Good";
  if (score >= 50) return "Fair";
  if (score >= 25) return "Getting Started";
  return "Incomplete";
}

export function ProfileScoreBar({ score, sections, role }: ProfileScoreBarProps) {
  const roundedScore = Math.round(score);
  const scoreColor = getScoreColor(roundedScore);
  const barColor = getBarColor(roundedScore);
  const label = getScoreLabel(roundedScore);

  return (
    <div className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b border-border shadow-sm safe-area-top">
      <div className="max-w-2xl mx-auto px-4 py-3 md:py-4">
        {/* Top row: score + label */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            {roundedScore >= 80 ? (
              <CheckCircle2 className="h-4 w-4 md:h-5 md:w-5 text-emerald-500" />
            ) : roundedScore >= 50 ? (
              <TrendingUp className="h-4 w-4 md:h-5 md:w-5 text-amber-500" />
            ) : (
              <AlertCircle className="h-4 w-4 md:h-5 md:w-5 text-destructive" />
            )}
            <span className="text-xs md:text-sm font-medium text-foreground">
              {role === "user" ? "Patient" : "Provider"} Profile Standard
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className={`text-lg md:text-xl font-bold ${scoreColor}`}>
              {roundedScore}%
            </span>
            <span className="text-[10px] md:text-xs text-muted-foreground font-medium">
              {label}
            </span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="h-2 md:h-2.5 w-full bg-muted rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ease-out ${barColor}`}
            style={{ width: `${roundedScore}%` }}
          />
        </div>

        {/* Section breakdown - scrollable on mobile */}
        <div className="flex gap-3 md:gap-4 mt-2 overflow-x-auto pb-0.5 scrollbar-hide">
          {sections.map((section) => {
            const pct = section.total > 0 ? Math.round((section.filled / section.total) * 100) : 0;
            return (
              <div key={section.label} className="flex items-center gap-1.5 shrink-0">
                <div className="h-1.5 w-1.5 rounded-full" style={{
                  backgroundColor: pct >= 100 ? "hsl(var(--primary))" : pct > 0 ? "hsl(43, 74%, 66%)" : "hsl(var(--muted-foreground))"
                }} />
                <span className="text-[10px] md:text-[11px] text-muted-foreground whitespace-nowrap">
                  {section.label}{" "}
                  <span className={pct >= 100 ? "text-primary font-medium" : "font-medium"}>
                    {section.filled}/{section.total}
                  </span>
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
