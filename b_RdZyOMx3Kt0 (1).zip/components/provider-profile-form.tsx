"use client";

import { useState, useMemo } from "react";
import { ProfileScoreBar } from "@/components/profile-score-bar";
import { Button } from "@/components/ui/button";
import {
  Building2,
  Stethoscope,
  Award,
  Globe,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
} from "lucide-react";

interface ProviderFormData {
  // Facility Info
  facilityName: string;
  facilityType: string;
  registrationNumber: string;
  yearEstablished: string;
  address: string;
  city: string;
  province: string;
  website: string;
  contactEmail: string;
  contactPhone: string;
  // Services & Specializations
  primarySpecialization: string;
  additionalSpecializations: string;
  treatmentsOffered: string;
  technologyEquipment: string;
  languagesSupported: string;
  internationalPatientServices: string;
  // Credentials & Accreditation
  jciAccredited: string;
  thaiMedCouncilLicense: string;
  otherAccreditations: string;
  keyPhysicians: string;
  avgExperienceYears: string;
  successRate: string;
  // International & Pricing
  medicalTourismPackages: string;
  estimatedPriceRange: string;
  insurancePartnerships: string;
  paymentMethods: string;
  visaSupportService: string;
  airportTransfer: string;
  accommodationPartners: string;
}

const INITIAL: ProviderFormData = {
  facilityName: "",
  facilityType: "",
  registrationNumber: "",
  yearEstablished: "",
  address: "",
  city: "",
  province: "",
  website: "",
  contactEmail: "",
  contactPhone: "",
  primarySpecialization: "",
  additionalSpecializations: "",
  treatmentsOffered: "",
  technologyEquipment: "",
  languagesSupported: "",
  internationalPatientServices: "",
  jciAccredited: "",
  thaiMedCouncilLicense: "",
  otherAccreditations: "",
  keyPhysicians: "",
  avgExperienceYears: "",
  successRate: "",
  medicalTourismPackages: "",
  estimatedPriceRange: "",
  insurancePartnerships: "",
  paymentMethods: "",
  visaSupportService: "",
  airportTransfer: "",
  accommodationPartners: "",
};

const SECTIONS = [
  {
    id: "facility",
    label: "Facility",
    icon: Building2,
    fields: [
      "facilityName",
      "facilityType",
      "registrationNumber",
      "yearEstablished",
      "address",
      "city",
      "province",
      "website",
      "contactEmail",
      "contactPhone",
    ] as (keyof ProviderFormData)[],
  },
  {
    id: "services",
    label: "Services",
    icon: Stethoscope,
    fields: [
      "primarySpecialization",
      "additionalSpecializations",
      "treatmentsOffered",
      "technologyEquipment",
      "languagesSupported",
      "internationalPatientServices",
    ] as (keyof ProviderFormData)[],
  },
  {
    id: "credentials",
    label: "Credentials",
    icon: Award,
    fields: [
      "jciAccredited",
      "thaiMedCouncilLicense",
      "otherAccreditations",
      "keyPhysicians",
      "avgExperienceYears",
      "successRate",
    ] as (keyof ProviderFormData)[],
  },
  {
    id: "international",
    label: "International",
    icon: Globe,
    fields: [
      "medicalTourismPackages",
      "estimatedPriceRange",
      "insurancePartnerships",
      "paymentMethods",
      "visaSupportService",
      "airportTransfer",
      "accommodationPartners",
    ] as (keyof ProviderFormData)[],
  },
];

const FIELD_LABELS: Record<keyof ProviderFormData, string> = {
  facilityName: "Facility Name",
  facilityType: "Facility Type",
  registrationNumber: "Registration Number",
  yearEstablished: "Year Established",
  address: "Street Address",
  city: "City",
  province: "Province",
  website: "Website URL",
  contactEmail: "Contact Email",
  contactPhone: "Contact Phone",
  primarySpecialization: "Primary Specialization",
  additionalSpecializations: "Additional Specializations",
  treatmentsOffered: "Treatments Offered",
  technologyEquipment: "Technology & Equipment",
  languagesSupported: "Languages Supported",
  internationalPatientServices: "International Patient Services",
  jciAccredited: "JCI Accredited",
  thaiMedCouncilLicense: "Thai Med Council License",
  otherAccreditations: "Other Accreditations",
  keyPhysicians: "Key Physicians",
  avgExperienceYears: "Average Experience (Years)",
  successRate: "Treatment Success Rate",
  medicalTourismPackages: "Medical Tourism Packages",
  estimatedPriceRange: "Estimated Price Range",
  insurancePartnerships: "Insurance Partnerships",
  paymentMethods: "Payment Methods Accepted",
  visaSupportService: "Visa Support Service",
  airportTransfer: "Airport Transfer",
  accommodationPartners: "Accommodation Partners",
};

const FIELD_PLACEHOLDERS: Record<keyof ProviderFormData, string> = {
  facilityName: "e.g. Bumrungrad International Hospital",
  facilityType: "",
  registrationNumber: "e.g. TH-MED-00123",
  yearEstablished: "e.g. 1997",
  address: "e.g. 33 Sukhumvit 3",
  city: "e.g. Bangkok",
  province: "e.g. Bangkok",
  website: "e.g. https://example.com",
  contactEmail: "e.g. info@hospital.com",
  contactPhone: "e.g. +66 2 011 3000",
  primarySpecialization: "e.g. Orthopedics",
  additionalSpecializations: "e.g. Cardiology, Oncology, Dermatology",
  treatmentsOffered: "e.g. Knee replacement, Hip replacement...",
  technologyEquipment: "e.g. da Vinci Robotic Surgery, MRI 3T",
  languagesSupported: "e.g. Thai, English, Japanese, Arabic",
  internationalPatientServices: "e.g. Interpreter, concierge, visa letter",
  jciAccredited: "",
  thaiMedCouncilLicense: "e.g. LIC-TH-456789",
  otherAccreditations: "e.g. ISO 9001, HA Thailand",
  keyPhysicians: "e.g. Dr. Somchai (Orthopedics), Dr. Lee (Cardiology)",
  avgExperienceYears: "e.g. 15",
  successRate: "e.g. 98%",
  medicalTourismPackages: "e.g. All-inclusive knee surgery package",
  estimatedPriceRange: "e.g. THB 200,000 - 500,000",
  insurancePartnerships: "e.g. Allianz, AXA, Bupa",
  paymentMethods: "e.g. Credit card, bank transfer, crypto",
  visaSupportService: "",
  airportTransfer: "",
  accommodationPartners: "e.g. Marriott Sukhumvit, Jasmine Resort",
};

const SELECT_OPTIONS: Partial<Record<keyof ProviderFormData, string[]>> = {
  facilityType: [
    "Hospital",
    "Clinic",
    "Specialized Center",
    "Dental Clinic",
    "Wellness Center",
    "Rehabilitation Center",
  ],
  jciAccredited: ["Yes", "No", "In Progress"],
  visaSupportService: ["Yes - Full Service", "Yes - Letter Only", "No"],
  airportTransfer: ["Yes - Complimentary", "Yes - Paid", "No"],
};

interface ProviderProfileFormProps {
  onComplete: () => void;
}

export function ProviderProfileForm({ onComplete }: ProviderProfileFormProps) {
  const [form, setForm] = useState<ProviderFormData>(INITIAL);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    facility: true,
    services: false,
    credentials: false,
    international: false,
  });

  const update = (field: keyof ProviderFormData, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const toggleSection = (id: string) => {
    setExpandedSections((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const scoreSections = useMemo(() => {
    return SECTIONS.map((s) => ({
      label: s.label,
      filled: s.fields.filter((f) => form[f].trim() !== "").length,
      total: s.fields.length,
    }));
  }, [form]);

  const totalScore = useMemo(() => {
    const totalFields = SECTIONS.reduce((sum, s) => sum + s.fields.length, 0);
    const filledFields = SECTIONS.reduce(
      (sum, s) => sum + s.fields.filter((f) => form[f].trim() !== "").length,
      0
    );
    return totalFields > 0 ? (filledFields / totalFields) * 100 : 0;
  }, [form]);

  const renderField = (field: keyof ProviderFormData) => {
    const options = SELECT_OPTIONS[field];
    const isTextarea =
      field === "treatmentsOffered" ||
      field === "technologyEquipment" ||
      field === "internationalPatientServices" ||
      field === "medicalTourismPackages" ||
      field === "keyPhysicians";
    const isFilled = form[field].trim() !== "";

    return (
      <div key={field} className="flex flex-col gap-1.5">
        <label className="flex items-center gap-1.5 text-xs md:text-sm font-medium text-foreground">
          {FIELD_LABELS[field]}
          {isFilled && <CheckCircle2 className="h-3 w-3 text-primary" />}
        </label>
        {options ? (
          <select
            value={form[field]}
            onChange={(e) => update(field, e.target.value)}
            className="w-full rounded-xl border border-border bg-muted/50 px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 appearance-none"
          >
            <option value="">Select...</option>
            {options.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        ) : isTextarea ? (
          <textarea
            value={form[field]}
            onChange={(e) => update(field, e.target.value)}
            placeholder={FIELD_PLACEHOLDERS[field]}
            rows={3}
            className="w-full rounded-xl border border-border bg-muted/50 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 resize-none"
          />
        ) : (
          <input
            type={
              field === "contactEmail"
                ? "email"
                : field === "contactPhone"
                  ? "tel"
                  : field === "website"
                    ? "url"
                    : "text"
            }
            value={form[field]}
            onChange={(e) => update(field, e.target.value)}
            placeholder={FIELD_PLACEHOLDERS[field]}
            className="w-full rounded-xl border border-border bg-muted/50 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
        )}
      </div>
    );
  };

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      <ProfileScoreBar score={totalScore} sections={scoreSections} role="provider" />

      <div className="flex-1 max-w-2xl mx-auto w-full px-4 py-5 md:py-8">
        <div className="mb-5 md:mb-8">
          <h1 className="text-lg md:text-xl font-bold text-foreground mb-1">
            Provider Profile Setup
          </h1>
          <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">
            Complete your facility profile to meet platform standards. A higher
            score increases your visibility to international patients.
          </p>
        </div>

        <div className="flex flex-col gap-3 md:gap-4">
          {SECTIONS.map((section) => {
            const filledCount = section.fields.filter((f) => form[f].trim() !== "").length;
            const isOpen = expandedSections[section.id];
            const isComplete = filledCount === section.fields.length;
            const Icon = section.icon;

            return (
              <div
                key={section.id}
                className={`bg-card rounded-2xl border transition-colors ${
                  isComplete ? "border-primary/40" : "border-border"
                }`}
              >
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full flex items-center justify-between p-4 md:p-5"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`h-9 w-9 md:h-10 md:w-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isComplete ? "bg-primary/10" : "bg-muted"
                      }`}
                    >
                      <Icon
                        className={`h-4 w-4 md:h-5 md:w-5 ${
                          isComplete ? "text-primary" : "text-muted-foreground"
                        }`}
                      />
                    </div>
                    <div className="text-left">
                      <h3 className="text-[13px] md:text-sm font-semibold text-foreground">
                        {section.label} Details
                      </h3>
                      <p className="text-[11px] md:text-xs text-muted-foreground">
                        {filledCount} of {section.fields.length} fields completed
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isComplete && (
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                    )}
                    <div className="hidden sm:flex h-1.5 w-16 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full transition-all duration-300"
                        style={{ width: `${(filledCount / section.fields.length) * 100}%` }}
                      />
                    </div>
                    {isOpen ? (
                      <ChevronUp className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 md:px-5 md:pb-5 flex flex-col gap-3 md:gap-4 border-t border-border pt-4">
                    {section.fields.map((field) => renderField(field))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-6 md:mt-8 pb-6">
          <Button
            onClick={onComplete}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-11 md:h-12 text-[13px] md:text-sm font-semibold"
          >
            Save Provider Profile
          </Button>
          <p className="text-center text-[11px] md:text-xs text-muted-foreground mt-3">
            Your profile will be reviewed before going live. You can update it anytime.
          </p>
        </div>
      </div>
    </div>
  );
}
