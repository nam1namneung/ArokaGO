"use client";

import Link from "next/link";
import { ArrowRight, Sparkles, CheckCircle2, MapPin, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('/hero-thailand.jpg')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-foreground/60 via-foreground/40 to-foreground/70" />

      <div className="relative z-10 flex flex-col items-center px-4 pt-20 pb-6 md:pt-24 md:pb-12 w-full max-w-4xl mx-auto text-center">
        {/* Trust badge */}
        <div className="flex items-center gap-2 bg-foreground/40 backdrop-blur-md border border-white/10 rounded-full px-3 py-1.5 md:px-5 md:py-2 mb-5 md:mb-8">
          <span className="h-2 w-2 md:h-2.5 md:w-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs md:text-sm font-medium text-white">
            Trusted by 50,000+ international patients
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl md:text-5xl lg:text-6xl font-bold text-white leading-tight text-balance mb-3 md:mb-6">
          Your Portal to World-Class Thai Medical Care
        </h1>
        <p className="text-sm md:text-xl text-white/80 max-w-2xl mb-6 md:mb-10 text-pretty leading-relaxed px-2">
          AI connects you to verified providers and offers agile support for
          consultations.
        </p>

        {/* Search card */}
        <div className="bg-card/95 backdrop-blur-md rounded-2xl shadow-2xl w-full max-w-2xl p-4 md:p-8">
          <div className="flex items-center gap-2 mb-3 md:mb-5">
            <span className="flex items-center gap-1.5 bg-foreground text-white text-[11px] md:text-xs font-semibold px-2.5 py-1 md:px-3 md:py-1.5 rounded-full">
              <Sparkles className="h-3 w-3 md:h-3.5 md:w-3.5" />
              AI-Assisted
            </span>
          </div>

          <textarea
            className="w-full rounded-xl border border-border bg-muted/50 px-3 py-2.5 md:px-4 md:py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 resize-none h-20 md:h-24"
            placeholder="Describe your medical needs, preferred location, budget or any specific requirement..."
          />

          <div className="flex flex-col gap-2.5 md:flex-row md:gap-3 mt-4 md:mt-5">
            <Link href="/chat" className="flex-1">
              <Button className="w-full bg-foreground text-white hover:bg-foreground/90 rounded-xl h-11 md:h-12 text-sm font-semibold gap-2">
                Search Providers
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/chat" className="flex-1">
              <Button
                variant="outline"
                className="w-full rounded-xl h-11 md:h-12 text-sm font-semibold border-border hover:bg-muted bg-transparent"
              >
                Match me with providers
              </Button>
            </Link>
          </div>

          <div className="flex flex-col items-center gap-2 md:flex-row md:flex-wrap md:justify-center md:gap-x-6 md:gap-y-2 mt-4 md:mt-6 text-[11px] md:text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 md:h-4 md:w-4 text-primary" />
              AI Instant Matching
            </span>
            <span className="flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 md:h-4 md:w-4 text-primary" />
              Auto Location Detection
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 md:h-4 md:w-4 text-primary" />
              24/7 Support
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
