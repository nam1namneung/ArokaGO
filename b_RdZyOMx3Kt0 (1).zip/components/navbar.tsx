"use client";

import Link from "next/link";
import { useState } from "react";
import { ChevronDown, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="absolute top-0 left-0 right-0 z-50">
      <nav className="flex items-center justify-between px-4 py-3 md:px-6 md:py-4 lg:px-12">
        <Link href="/" className="flex items-center gap-1">
          <span className="text-xl md:text-2xl font-bold text-white tracking-tight">
            Aroka
          </span>
          <span className="text-xl md:text-2xl font-bold text-primary">GO</span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-8">
          <button className="flex items-center gap-1 text-sm font-medium text-white/90 hover:text-white transition-colors">
            Find Providers
            <ChevronDown className="h-4 w-4" />
          </button>
          <button className="flex items-center gap-1 text-sm font-medium text-white/90 hover:text-white transition-colors">
            Knowledge
            <ChevronDown className="h-4 w-4" />
          </button>
          <button className="flex items-center gap-1 text-sm font-medium text-white/90 hover:text-white transition-colors">
            Company
            <ChevronDown className="h-4 w-4" />
          </button>
          <Link
            href="/interpreters"
            className="text-sm font-medium text-white/90 hover:text-white transition-colors"
          >
            Interpreters
          </Link>
          <Link
            href="#"
            className="text-sm font-medium text-white/90 hover:text-white transition-colors"
          >
            Community
          </Link>
        </div>

        <div className="hidden lg:flex items-center gap-3">
          <Link
            href="/onboarding"
            className="text-sm font-medium text-white/90 hover:text-white transition-colors"
          >
            Sign Up
          </Link>
          <Link href="/chat">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-6">
              Start Consultation
            </Button>
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          className="lg:hidden text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-foreground/95 backdrop-blur-md px-6 pb-6 pt-2">
          <div className="flex flex-col gap-4">
            <button className="flex items-center gap-1 text-sm font-medium text-white/90 hover:text-white">
              Find Providers <ChevronDown className="h-4 w-4" />
            </button>
            <button className="flex items-center gap-1 text-sm font-medium text-white/90 hover:text-white">
              Knowledge <ChevronDown className="h-4 w-4" />
            </button>
            <button className="flex items-center gap-1 text-sm font-medium text-white/90 hover:text-white">
              Company <ChevronDown className="h-4 w-4" />
            </button>
            <Link href="/interpreters" className="text-sm font-medium text-white/90 hover:text-white">
              Interpreters
            </Link>
            <Link href="#" className="text-sm font-medium text-white/90 hover:text-white">
              Community
            </Link>
            <Link href="/onboarding" className="text-sm font-medium text-white/90 hover:text-white">
              Sign Up
            </Link>
            <Link href="/chat">
              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-full">
                Start Consultation
              </Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
