"use client";

import React from "react"

import { useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Star,
  Search,
  Filter,
  Languages,
  ShieldCheck,
  FileText,
  Clock,
  ChevronDown,
  X,
  Video,
  BadgeCheck,
  Stethoscope,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface Interpreter {
  id: number;
  name: string;
  avatar: string;
  rating: number;
  reviewCount: number;
  languages: string[];
  specializations: string[];
  description: string;
  experience: string;
  commissionRate: string;
  verified: boolean;
  available: boolean;
  completedSessions: number;
}

const INTERPRETERS: Interpreter[] = [
  {
    id: 1,
    name: "Somchai Prasert",
    avatar: "SP",
    rating: 4.9,
    reviewCount: 342,
    languages: ["Thai", "English", "Mandarin"],
    specializations: ["Orthopedics", "Cardiology", "General Surgery"],
    description:
      "Certified medical interpreter with 8+ years of experience in hospital settings. Specialized in surgical terminology and patient-doctor communication for international patients.",
    experience: "8 years",
    commissionRate: "THB 1,500/session",
    verified: true,
    available: true,
    completedSessions: 1240,
  },
  {
    id: 2,
    name: "Nattaya Wongchai",
    avatar: "NW",
    rating: 4.8,
    reviewCount: 289,
    languages: ["Thai", "English", "Japanese"],
    specializations: ["Dermatology", "Cosmetic Surgery", "Dental"],
    description:
      "Former nurse turned professional medical interpreter. Expert in cosmetic and dental procedure terminology with deep understanding of patient care workflows.",
    experience: "6 years",
    commissionRate: "THB 1,200/session",
    verified: true,
    available: true,
    completedSessions: 890,
  },
  {
    id: 3,
    name: "Prasit Kaewmanee",
    avatar: "PK",
    rating: 4.7,
    reviewCount: 198,
    languages: ["Thai", "English", "Korean"],
    specializations: ["Oncology", "Neurology", "Internal Medicine"],
    description:
      "Medical terminology specialist with background in pharmaceutical research. Provides accurate translation for complex medical diagnoses and treatment plans.",
    experience: "5 years",
    commissionRate: "THB 1,800/session",
    verified: true,
    available: false,
    completedSessions: 720,
  },
  {
    id: 4,
    name: "Areeya Thongsuk",
    avatar: "AT",
    rating: 4.9,
    reviewCount: 415,
    languages: ["Thai", "English", "Arabic"],
    specializations: ["Obstetrics", "Pediatrics", "Fertility"],
    description:
      "Highly experienced interpreter focusing on reproductive health and pediatric care. Known for compassionate communication and cultural sensitivity.",
    experience: "10 years",
    commissionRate: "THB 2,000/session",
    verified: true,
    available: true,
    completedSessions: 1580,
  },
  {
    id: 5,
    name: "Kittipong Srisawat",
    avatar: "KS",
    rating: 4.6,
    reviewCount: 156,
    languages: ["Thai", "English", "Russian"],
    specializations: ["Rehabilitation", "Sports Medicine", "Physiotherapy"],
    description:
      "Sports medicine interpreter with experience working in top Bangkok rehabilitation centers. Fluent in medical and fitness-related terminology.",
    experience: "4 years",
    commissionRate: "THB 1,000/session",
    verified: true,
    available: true,
    completedSessions: 430,
  },
  {
    id: 6,
    name: "Wipawee Jantaraksa",
    avatar: "WJ",
    rating: 4.8,
    reviewCount: 267,
    languages: ["Thai", "English", "German", "French"],
    specializations: ["Cardiology", "General Surgery", "Emergency Medicine"],
    description:
      "Multilingual medical interpreter with European hospital experience. Adept at handling emergency situations and complex surgical consultations.",
    experience: "7 years",
    commissionRate: "THB 1,600/session",
    verified: true,
    available: true,
    completedSessions: 980,
  },
  {
    id: 7,
    name: "Tanawat Sukhum",
    avatar: "TS",
    rating: 4.5,
    reviewCount: 112,
    languages: ["Thai", "English", "Hindi"],
    specializations: ["Ophthalmology", "ENT", "Dental"],
    description:
      "Specialized in eye and ear-nose-throat medical terminology. Provides detailed interpretation for diagnostic procedures and post-operative care instructions.",
    experience: "3 years",
    commissionRate: "THB 900/session",
    verified: false,
    available: true,
    completedSessions: 280,
  },
  {
    id: 8,
    name: "Pimchanok Rattana",
    avatar: "PR",
    rating: 4.9,
    reviewCount: 378,
    languages: ["Thai", "English", "Vietnamese", "Lao"],
    specializations: ["Traditional Medicine", "Wellness", "Holistic Care"],
    description:
      "Expert in both modern and traditional Thai medicine terminology. Bridges communication between traditional healers and international patients seeking holistic treatments.",
    experience: "9 years",
    commissionRate: "THB 1,400/session",
    verified: true,
    available: true,
    completedSessions: 1120,
  },
];

const LANGUAGE_OPTIONS = [
  "All Languages",
  "English",
  "Mandarin",
  "Japanese",
  "Korean",
  "Arabic",
  "Russian",
  "German",
  "French",
  "Hindi",
  "Vietnamese",
];

const SPECIALIZATION_OPTIONS = [
  "All Specializations",
  "Orthopedics",
  "Cardiology",
  "Cosmetic Surgery",
  "Dental",
  "Oncology",
  "Pediatrics",
  "Fertility",
  "Rehabilitation",
  "General Surgery",
];

export function InterpretersListing() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("All Languages");
  const [selectedSpecialization, setSelectedSpecialization] =
    useState("All Specializations");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedInterpreter, setSelectedInterpreter] =
    useState<Interpreter | null>(null);

  const filtered = INTERPRETERS.filter((interp) => {
    const matchesSearch =
      interp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      interp.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      interp.specializations.some((s) =>
        s.toLowerCase().includes(searchQuery.toLowerCase())
      );
    const matchesLang =
      selectedLanguage === "All Languages" ||
      interp.languages.includes(selectedLanguage);
    const matchesSpec =
      selectedSpecialization === "All Specializations" ||
      interp.specializations.includes(selectedSpecialization);
    return matchesSearch && matchesLang && matchesSpec;
  });

  // Detail view for a selected interpreter
  if (selectedInterpreter) {
    return (
      <InterpreterDetail
        interpreter={selectedInterpreter}
        onBack={() => setSelectedInterpreter(null)}
      />
    );
  }

  return (
    <div className="min-h-[100dvh] bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground px-3 py-3 md:px-4 md:py-4 safe-area-top">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <Link href="/" className="flex items-center p-1">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-base md:text-lg font-semibold">
              Medical Interpreters
            </h1>
            <p className="text-[11px] md:text-xs opacity-80">
              Hire verified interpreters for your medical journey
            </p>
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-3 py-4 md:px-4 md:py-6">
        {/* Search bar */}
        <div className="flex items-center gap-2 mb-3 md:mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, language, or specialty..."
              className="w-full pl-9 pr-3 py-2.5 md:py-3 bg-card border border-border rounded-xl text-[13px] md:text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2.5 md:p-3 rounded-xl border transition-colors shrink-0 ${
              showFilters
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card border-border text-foreground hover:bg-muted"
            }`}
            aria-label="Toggle filters"
          >
            <Filter className="h-4 w-4" />
          </button>
        </div>

        {/* Filter dropdowns */}
        {showFilters && (
          <div className="flex flex-col gap-2 mb-4 md:flex-row md:gap-3 md:mb-5">
            <div className="relative flex-1">
              <Languages className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
              <select
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="w-full pl-9 pr-8 py-2 md:py-2.5 bg-card border border-border rounded-xl text-[13px] md:text-sm text-foreground appearance-none focus:outline-none focus:ring-2 focus:ring-primary/40"
              >
                {LANGUAGE_OPTIONS.map((lang) => (
                  <option key={lang} value={lang}>
                    {lang}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
            </div>
            <div className="relative flex-1">
              <Stethoscope className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
              <select
                value={selectedSpecialization}
                onChange={(e) => setSelectedSpecialization(e.target.value)}
                className="w-full pl-9 pr-8 py-2 md:py-2.5 bg-card border border-border rounded-xl text-[13px] md:text-sm text-foreground appearance-none focus:outline-none focus:ring-2 focus:ring-primary/40"
              >
                {SPECIALIZATION_OPTIONS.map((spec) => (
                  <option key={spec} value={spec}>
                    {spec}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
            </div>
            {(selectedLanguage !== "All Languages" ||
              selectedSpecialization !== "All Specializations") && (
              <button
                onClick={() => {
                  setSelectedLanguage("All Languages");
                  setSelectedSpecialization("All Specializations");
                }}
                className="flex items-center justify-center gap-1 text-xs text-muted-foreground hover:text-foreground py-2 transition-colors"
              >
                <X className="h-3 w-3" />
                Clear filters
              </button>
            )}
          </div>
        )}

        {/* Results count */}
        <p className="text-[11px] md:text-xs text-muted-foreground mb-3 md:mb-4">
          {filtered.length} interpreter{filtered.length !== 1 ? "s" : ""}{" "}
          available
        </p>

        {/* Interpreter cards */}
        <div className="flex flex-col gap-3 md:gap-4">
          {filtered.map((interp) => (
            <button
              key={interp.id}
              onClick={() => setSelectedInterpreter(interp)}
              className="bg-card rounded-2xl border border-border shadow-sm p-4 md:p-5 text-left hover:shadow-md hover:border-primary/30 transition-all w-full"
            >
              <div className="flex items-start gap-3">
                {/* Avatar */}
                <div
                  className={`h-11 w-11 md:h-12 md:w-12 rounded-full flex items-center justify-center shrink-0 text-[13px] md:text-sm font-bold ${
                    interp.available
                      ? "bg-primary/10 text-primary"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {interp.avatar}
                </div>

                <div className="flex-1 min-w-0">
                  {/* Name and verification */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className="text-[13px] md:text-sm font-semibold text-foreground truncate">
                      {interp.name}
                    </h3>
                    {interp.verified && (
                      <BadgeCheck className="h-4 w-4 text-primary shrink-0" />
                    )}
                    {!interp.available && (
                      <span className="text-[10px] bg-muted text-muted-foreground px-1.5 py-0.5 rounded-full font-medium">
                        Unavailable
                      </span>
                    )}
                  </div>

                  {/* Rating */}
                  <div className="flex items-center gap-1.5 mt-1">
                    <div className="flex items-center gap-0.5">
                      <Star className="h-3 w-3 md:h-3.5 md:w-3.5 fill-amber-400 text-amber-400" />
                      <span className="text-[12px] md:text-[13px] font-semibold text-foreground">
                        {interp.rating}
                      </span>
                    </div>
                    <span className="text-[11px] text-muted-foreground">
                      ({interp.reviewCount} reviews)
                    </span>
                    <span className="text-[11px] text-muted-foreground hidden sm:inline">
                      {interp.completedSessions} sessions
                    </span>
                  </div>

                  {/* Languages */}
                  <div className="flex items-center gap-1 mt-2 flex-wrap">
                    {interp.languages.map((lang) => (
                      <span
                        key={lang}
                        className="text-[10px] md:text-[11px] bg-accent text-accent-foreground px-2 py-0.5 rounded-full font-medium"
                      >
                        {lang}
                      </span>
                    ))}
                  </div>

                  {/* Description preview */}
                  <p className="text-[11px] md:text-xs text-muted-foreground mt-2 line-clamp-2 leading-relaxed">
                    {interp.description}
                  </p>

                  {/* Fee */}
                  <div className="flex items-center justify-between mt-2.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {interp.specializations.slice(0, 2).map((spec) => (
                        <span
                          key={spec}
                          className="text-[10px] md:text-[11px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded"
                        >
                          {spec}
                        </span>
                      ))}
                      {interp.specializations.length > 2 && (
                        <span className="text-[10px] text-muted-foreground">
                          +{interp.specializations.length - 2}
                        </span>
                      )}
                    </div>
                    <span className="text-[12px] md:text-[13px] font-semibold text-primary shrink-0 ml-2">
                      {interp.commissionRate}
                    </span>
                  </div>
                </div>
              </div>
            </button>
          ))}

          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Languages className="h-10 w-10 text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground">
                No interpreters found matching your criteria
              </p>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setSelectedLanguage("All Languages");
                  setSelectedSpecialization("All Specializations");
                }}
                className="text-xs text-primary mt-2 hover:underline"
              >
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// --- Interpreter Detail View ---

function InterpreterDetail({
  interpreter,
  onBack,
}: {
  interpreter: Interpreter;
  onBack: () => void;
}) {
  const [showHireForm, setShowHireForm] = useState(false);

  return (
    <div className="min-h-[100dvh] bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground px-3 py-3 md:px-4 md:py-4 safe-area-top">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <button onClick={onBack} className="flex items-center p-1">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-base md:text-lg font-semibold">
              Interpreter Profile
            </h1>
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-3 py-5 md:px-4 md:py-8">
        {/* Profile card */}
        <div className="bg-card rounded-2xl border border-border shadow-lg p-5 md:p-6 mb-4 md:mb-5">
          <div className="flex items-start gap-4">
            <div
              className={`h-14 w-14 md:h-16 md:w-16 rounded-full flex items-center justify-center shrink-0 text-lg md:text-xl font-bold ${
                interpreter.available
                  ? "bg-primary/10 text-primary"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {interpreter.avatar}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base md:text-lg font-bold text-foreground">
                  {interpreter.name}
                </h2>
                {interpreter.verified && (
                  <BadgeCheck className="h-5 w-5 text-primary shrink-0" />
                )}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                  <span className="text-[13px] font-semibold text-foreground">
                    {interpreter.rating}
                  </span>
                </div>
                <span className="text-[12px] text-muted-foreground">
                  ({interpreter.reviewCount} reviews)
                </span>
              </div>
              <div className="flex items-center gap-3 mt-2 text-[12px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  {interpreter.experience}
                </span>
                <span>{interpreter.completedSessions} sessions</span>
              </div>
            </div>
          </div>

          <p className="text-[13px] md:text-sm text-foreground mt-4 leading-relaxed">
            {interpreter.description}
          </p>

          {/* Price */}
          <div className="flex items-center justify-between bg-accent/50 rounded-xl p-3 mt-4">
            <span className="text-[12px] md:text-[13px] text-muted-foreground">
              Commission rate
            </span>
            <span className="text-[14px] md:text-base font-bold text-primary">
              {interpreter.commissionRate}
            </span>
          </div>
        </div>

        {/* Info sections */}
        <div className="flex flex-col gap-3 md:gap-4">
          {/* Languages */}
          <div className="bg-card rounded-2xl border border-border p-4 md:p-5">
            <h3 className="text-[13px] md:text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
              <Languages className="h-4 w-4 text-primary" />
              Languages
            </h3>
            <div className="flex flex-wrap gap-2">
              {interpreter.languages.map((lang) => (
                <span
                  key={lang}
                  className="text-[12px] md:text-[13px] bg-accent text-accent-foreground px-3 py-1.5 rounded-full font-medium"
                >
                  {lang}
                </span>
              ))}
            </div>
          </div>

          {/* Specializations */}
          <div className="bg-card rounded-2xl border border-border p-4 md:p-5">
            <h3 className="text-[13px] md:text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
              <Stethoscope className="h-4 w-4 text-primary" />
              Medical Specializations
            </h3>
            <div className="flex flex-wrap gap-2">
              {interpreter.specializations.map((spec) => (
                <span
                  key={spec}
                  className="text-[12px] md:text-[13px] bg-muted text-foreground px-3 py-1.5 rounded-full font-medium"
                >
                  {spec}
                </span>
              ))}
            </div>
          </div>

          {/* Verification */}
          <div className="bg-card rounded-2xl border border-border p-4 md:p-5">
            <h3 className="text-[13px] md:text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
              <ShieldCheck className="h-4 w-4 text-primary" />
              Verification Status
            </h3>
            <div className="flex flex-col gap-2.5">
              <div className="flex items-center gap-2.5">
                <div
                  className={`h-5 w-5 rounded-full flex items-center justify-center ${
                    interpreter.verified
                      ? "bg-primary/10"
                      : "bg-muted"
                  }`}
                >
                  {interpreter.verified ? (
                    <BadgeCheck className="h-3.5 w-3.5 text-primary" />
                  ) : (
                    <X className="h-3 w-3 text-muted-foreground" />
                  )}
                </div>
                <span className="text-[12px] md:text-[13px] text-foreground">
                  Identity Verified
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <div
                  className={`h-5 w-5 rounded-full flex items-center justify-center ${
                    interpreter.verified
                      ? "bg-primary/10"
                      : "bg-muted"
                  }`}
                >
                  {interpreter.verified ? (
                    <FileText className="h-3.5 w-3.5 text-primary" />
                  ) : (
                    <X className="h-3 w-3 text-muted-foreground" />
                  )}
                </div>
                <span className="text-[12px] md:text-[13px] text-foreground">
                  Supporting Documents Submitted
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <div className="h-5 w-5 rounded-full flex items-center justify-center bg-primary/10">
                  <Stethoscope className="h-3.5 w-3.5 text-primary" />
                </div>
                <span className="text-[12px] md:text-[13px] text-foreground">
                  Medical Terminology Certified
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Hire button / form */}
        <div className="mt-5 md:mt-6 pb-4 md:pb-0">
          {!showHireForm ? (
            <Button
              onClick={() => setShowHireForm(true)}
              disabled={!interpreter.available}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-11 md:h-12 text-[13px] md:text-sm font-semibold gap-2 shadow-lg disabled:opacity-40"
            >
              <Video className="h-4 w-4" />
              {interpreter.available
                ? "Hire This Interpreter"
                : "Currently Unavailable"}
            </Button>
          ) : (
            <HireForm
              interpreter={interpreter}
              onCancel={() => setShowHireForm(false)}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// --- Hire Form ---

function HireForm({
  interpreter,
  onCancel,
}: {
  interpreter: Interpreter;
  onCancel: () => void;
}) {
  const [step, setStep] = useState<"form" | "success">("form");
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    treatment: "",
    date: "",
    notes: "",
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStep("success");
  }

  if (step === "success") {
    return (
      <div className="bg-card rounded-2xl border border-border p-5 md:p-6 text-center">
        <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
          <BadgeCheck className="h-6 w-6 text-primary" />
        </div>
        <h3 className="text-base md:text-lg font-bold text-foreground mb-2">
          Request Submitted
        </h3>
        <p className="text-[13px] text-muted-foreground leading-relaxed mb-4">
          Your interpreter hire request for{" "}
          <span className="font-semibold text-foreground">
            {interpreter.name}
          </span>{" "}
          has been sent. You will receive a confirmation email with payment
          details and session information.
        </p>
        <div className="bg-accent/50 rounded-xl p-3 mb-5 text-[12px] text-accent-foreground">
          Commission fee of{" "}
          <span className="font-semibold">{interpreter.commissionRate}</span>{" "}
          will be charged after the session is confirmed.
        </div>
        <div className="flex flex-col gap-2.5">
          <Link href="/chat">
            <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-10 md:h-11 text-[13px] md:text-sm">
              Back to Chat
            </Button>
          </Link>
          <Link href="/">
            <Button
              variant="outline"
              className="w-full rounded-xl h-10 md:h-11 text-[13px] md:text-sm bg-transparent"
            >
              Go to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-card rounded-2xl border border-border p-4 md:p-5"
    >
      <h3 className="text-[13px] md:text-sm font-semibold text-foreground mb-4">
        Hire {interpreter.name}
      </h3>

      <div className="flex flex-col gap-3">
        <div>
          <label className="text-[11px] md:text-xs font-medium text-foreground mb-1 block">
            Full Name <span className="text-destructive">*</span>
          </label>
          <input
            required
            type="text"
            value={formData.fullName}
            onChange={(e) =>
              setFormData({ ...formData, fullName: e.target.value })
            }
            className="w-full px-3 py-2 md:py-2.5 bg-muted/50 border border-border rounded-xl text-[13px] md:text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            placeholder="Enter your full name"
          />
        </div>

        <div>
          <label className="text-[11px] md:text-xs font-medium text-foreground mb-1 block">
            Email Address <span className="text-destructive">*</span>
          </label>
          <input
            required
            type="email"
            value={formData.email}
            onChange={(e) =>
              setFormData({ ...formData, email: e.target.value })
            }
            className="w-full px-3 py-2 md:py-2.5 bg-muted/50 border border-border rounded-xl text-[13px] md:text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            placeholder="your@email.com"
          />
        </div>

        <div>
          <label className="text-[11px] md:text-xs font-medium text-foreground mb-1 block">
            Treatment / Procedure <span className="text-destructive">*</span>
          </label>
          <input
            required
            type="text"
            value={formData.treatment}
            onChange={(e) =>
              setFormData({ ...formData, treatment: e.target.value })
            }
            className="w-full px-3 py-2 md:py-2.5 bg-muted/50 border border-border rounded-xl text-[13px] md:text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            placeholder="e.g. Knee Replacement Surgery"
          />
        </div>

        <div>
          <label className="text-[11px] md:text-xs font-medium text-foreground mb-1 block">
            Preferred Date <span className="text-destructive">*</span>
          </label>
          <input
            required
            type="date"
            value={formData.date}
            onChange={(e) =>
              setFormData({ ...formData, date: e.target.value })
            }
            className="w-full px-3 py-2 md:py-2.5 bg-muted/50 border border-border rounded-xl text-[13px] md:text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
        </div>

        <div>
          <label className="text-[11px] md:text-xs font-medium text-foreground mb-1 block">
            Additional Notes
          </label>
          <textarea
            value={formData.notes}
            onChange={(e) =>
              setFormData({ ...formData, notes: e.target.value })
            }
            className="w-full px-3 py-2 md:py-2.5 bg-muted/50 border border-border rounded-xl text-[13px] md:text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 resize-none h-16 md:h-20"
            placeholder="Any special requirements or information..."
          />
        </div>
      </div>

      <div className="bg-accent/50 rounded-xl p-3 mt-4 text-[11px] md:text-[12px] text-accent-foreground leading-relaxed">
        <div className="flex items-start gap-2">
          <ShieldCheck className="h-4 w-4 shrink-0 mt-0.5" />
          <span>
            Identity verification is required. The interpreter&apos;s credentials and supporting documents have been verified by ArokaGO. Commission fee of{" "}
            <span className="font-semibold">{interpreter.commissionRate}</span>{" "}
            applies per session.
          </span>
        </div>
      </div>

      <div className="flex flex-col gap-2.5 mt-4">
        <Button
          type="submit"
          className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-10 md:h-11 text-[13px] md:text-sm font-semibold"
        >
          Submit Hire Request
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="w-full rounded-xl h-10 md:h-11 text-[13px] md:text-sm bg-transparent"
        >
          Cancel
        </Button>
      </div>
    </form>
  );
}
