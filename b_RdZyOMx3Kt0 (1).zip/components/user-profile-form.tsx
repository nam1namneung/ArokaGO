"use client";

import { useState, useMemo } from "react";
import { ProfileScoreBar } from "@/components/profile-score-bar";
import { Button } from "@/components/ui/button";
import {
  User,
  Heart,
  Plane,
  FileText,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
} from "lucide-react";

interface UserFormData {
  // Personal Info
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  nationality: string;
  passportNumber: string;
  gender: string;
  // Medical Info
  primaryCondition: string;
  treatmentType: string;
  medicalHistory: string;
  currentMedications: string;
  allergies: string;
  bloodType: string;
  // Travel Preferences
  preferredCity: string;
  arrivalDate: string;
  departureDate: string;
  accommodation: string;
  travelCompanion: string;
  // Insurance & Documents
  insuranceProvider: string;
  policyNumber: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  additionalNotes: string;
}

const INITIAL: UserFormData = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  dateOfBirth: "",
  nationality: "",
  passportNumber: "",
  gender: "",
  primaryCondition: "",
  treatmentType: "",
  medicalHistory: "",
  currentMedications: "",
  allergies: "",
  bloodType: "",
  preferredCity: "",
  arrivalDate: "",
  departureDate: "",
  accommodation: "",
  travelCompanion: "",
  insuranceProvider: "",
  policyNumber: "",
  emergencyContactName: "",
  emergencyContactPhone: "",
  additionalNotes: "",
};

const SECTIONS = [
  {
    id: "personal",
    label: "Personal",
    icon: User,
    fields: [
      "firstName",
      "lastName",
      "email",
      "phone",
      "dateOfBirth",
      "nationality",
      "passportNumber",
      "gender",
    ] as (keyof UserFormData)[],
  },
  {
    id: "medical",
    label: "Medical",
    icon: Heart,
    fields: [
      "primaryCondition",
      "treatmentType",
      "medicalHistory",
      "currentMedications",
      "allergies",
      "bloodType",
    ] as (keyof UserFormData)[],
  },
  {
    id: "travel",
    label: "Travel",
    icon: Plane,
    fields: [
      "preferredCity",
      "arrivalDate",
      "departureDate",
      "accommodation",
      "travelCompanion",
    ] as (keyof UserFormData)[],
  },
  {
    id: "documents",
    label: "Documents",
    icon: FileText,
    fields: [
      "insuranceProvider",
      "policyNumber",
      "emergencyContactName",
      "emergencyContactPhone",
      "additionalNotes",
    ] as (keyof UserFormData)[],
  },
];

const FIELD_LABELS: Record<keyof UserFormData, string> = {
  firstName: "First Name",
  lastName: "Last Name",
  email: "Email Address",
  phone: "Phone Number",
  dateOfBirth: "Date of Birth",
  nationality: "Nationality",
  passportNumber: "Passport Number",
  gender: "Gender",
  primaryCondition: "Primary Condition",
  treatmentType: "Treatment Type",
  medicalHistory: "Medical History",
  currentMedications: "Current Medications",
  allergies: "Allergies",
  bloodType: "Blood Type",
  preferredCity: "Preferred City",
  arrivalDate: "Arrival Date",
  departureDate: "Departure Date",
  accommodation: "Accommodation Type",
  travelCompanion: "Travel Companion",
  insuranceProvider: "Insurance Provider",
  policyNumber: "Policy Number",
  emergencyContactName: "Emergency Contact Name",
  emergencyContactPhone: "Emergency Contact Phone",
  additionalNotes: "Additional Notes",
};

const FIELD_PLACEHOLDERS: Record<keyof UserFormData, string> = {
  firstName: "e.g. John",
  lastName: "e.g. Doe",
  email: "e.g. john@example.com",
  phone: "e.g. +1 555 123 4567",
  dateOfBirth: "",
  nationality: "e.g. American",
  passportNumber: "e.g. AB1234567",
  gender: "",
  primaryCondition: "e.g. Knee osteoarthritis",
  treatmentType: "e.g. Knee replacement surgery",
  medicalHistory: "List previous surgeries, conditions...",
  currentMedications: "e.g. Ibuprofen 400mg daily",
  allergies: "e.g. Penicillin, Latex",
  bloodType: "",
  preferredCity: "e.g. Bangkok",
  arrivalDate: "",
  departureDate: "",
  accommodation: "",
  travelCompanion: "e.g. Spouse, alone",
  insuranceProvider: "e.g. Allianz Partners",
  policyNumber: "e.g. POL-123456",
  emergencyContactName: "e.g. Jane Doe",
  emergencyContactPhone: "e.g. +1 555 987 6543",
  additionalNotes: "Any special requests or notes...",
};

const SELECT_OPTIONS: Partial<Record<keyof UserFormData, string[]>> = {
  gender: ["Male", "Female", "Non-binary", "Prefer not to say"],
  bloodType: ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
  accommodation: ["Hotel", "Serviced Apartment", "Hospital Room", "Hostel", "No preference"],
};

interface UserProfileFormProps {
  onComplete: () => void;
}

export function UserProfileForm({ onComplete }: UserProfileFormProps) {
  const [form, setForm] = useState<UserFormData>(INITIAL);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    personal: true,
    medical: false,
    travel: false,
    documents: false,
  });

  const update = (field: keyof UserFormData, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const toggleSection = (id: string) => {
    setExpandedSections((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const scoreSections = useMemo(() => {
    return SECTIONS.map((s) => ({
      label: s.label,
      filled: s.fields.filter((f) => form[f].trim() !== "").length,
      total: s.fields.length,
    }));
  }, [form]);

  const totalScore = useMemo(() => {
    const totalFields = SECTIONS.reduce((sum, s) => sum + s.fields.length, 0);
    const filledFields = SECTIONS.reduce(
      (sum, s) => sum + s.fields.filter((f) => form[f].trim() !== "").length,
      0
    );
    return totalFields > 0 ? (filledFields / totalFields) * 100 : 0;
  }, [form]);

  const renderField = (field: keyof UserFormData) => {
    const options = SELECT_OPTIONS[field];
    const isTextarea = field === "medicalHistory" || field === "additionalNotes";
    const isDate = field === "dateOfBirth" || field === "arrivalDate" || field === "departureDate";
    const isFilled = form[field].trim() !== "";

    return (
      <div key={field} className="flex flex-col gap-1.5">
        <label className="flex items-center gap-1.5 text-xs md:text-sm font-medium text-foreground">
          {FIELD_LABELS[field]}
          {isFilled && <CheckCircle2 className="h-3 w-3 text-primary" />}
        </label>
        {options ? (
          <select
            value={form[field]}
            onChange={(e) => update(field, e.target.value)}
            className="w-full rounded-xl border border-border bg-muted/50 px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 appearance-none"
          >
            <option value="">Select...</option>
            {options.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        ) : isTextarea ? (
          <textarea
            value={form[field]}
            onChange={(e) => update(field, e.target.value)}
            placeholder={FIELD_PLACEHOLDERS[field]}
            rows={3}
            className="w-full rounded-xl border border-border bg-muted/50 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 resize-none"
          />
        ) : isDate ? (
          <input
            type="date"
            value={form[field]}
            onChange={(e) => update(field, e.target.value)}
            className="w-full rounded-xl border border-border bg-muted/50 px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
        ) : (
          <input
            type={field === "email" ? "email" : field === "phone" || field === "emergencyContactPhone" ? "tel" : "text"}
            value={form[field]}
            onChange={(e) => update(field, e.target.value)}
            placeholder={FIELD_PLACEHOLDERS[field]}
            className="w-full rounded-xl border border-border bg-muted/50 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
        )}
      </div>
    );
  };

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      <ProfileScoreBar score={totalScore} sections={scoreSections} role="user" />

      <div className="flex-1 max-w-2xl mx-auto w-full px-4 py-5 md:py-8">
        <div className="mb-5 md:mb-8">
          <h1 className="text-lg md:text-xl font-bold text-foreground mb-1">
            Patient Profile Setup
          </h1>
          <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">
            Fill in your details to match the platform standard. The more complete
            your profile, the better we can connect you with the right providers.
          </p>
        </div>

        <div className="flex flex-col gap-3 md:gap-4">
          {SECTIONS.map((section) => {
            const filledCount = section.fields.filter((f) => form[f].trim() !== "").length;
            const isOpen = expandedSections[section.id];
            const isComplete = filledCount === section.fields.length;
            const Icon = section.icon;

            return (
              <div
                key={section.id}
                className={`bg-card rounded-2xl border transition-colors ${
                  isComplete ? "border-primary/40" : "border-border"
                }`}
              >
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full flex items-center justify-between p-4 md:p-5"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`h-9 w-9 md:h-10 md:w-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isComplete ? "bg-primary/10" : "bg-muted"
                      }`}
                    >
                      <Icon
                        className={`h-4 w-4 md:h-5 md:w-5 ${
                          isComplete ? "text-primary" : "text-muted-foreground"
                        }`}
                      />
                    </div>
                    <div className="text-left">
                      <h3 className="text-[13px] md:text-sm font-semibold text-foreground">
                        {section.label} Information
                      </h3>
                      <p className="text-[11px] md:text-xs text-muted-foreground">
                        {filledCount} of {section.fields.length} fields completed
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isComplete && (
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                    )}
                    {/* Mini progress */}
                    <div className="hidden sm:flex h-1.5 w-16 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full transition-all duration-300"
                        style={{ width: `${(filledCount / section.fields.length) * 100}%` }}
                      />
                    </div>
                    {isOpen ? (
                      <ChevronUp className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 md:px-5 md:pb-5 flex flex-col gap-3 md:gap-4 border-t border-border pt-4">
                    {section.fields.map((field) => renderField(field))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-6 md:mt-8 pb-6">
          <Button
            onClick={onComplete}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-11 md:h-12 text-[13px] md:text-sm font-semibold"
          >
            Save Profile
          </Button>
          <p className="text-center text-[11px] md:text-xs text-muted-foreground mt-3">
            You can update your profile anytime from settings.
          </p>
        </div>
      </div>
    </div>
  );
}
